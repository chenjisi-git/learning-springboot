package com.lagou.springboot.service;

import com.lagou.springboot.entity.Article;
import com.lagou.springboot.util.PageEntity;
import org.springframework.data.domain.Page;

import java.util.List;

/**
 * @author cjs
 * @version 1.0.0
 * @className ArticleService
 * @description TODO
 * @createTime 2020年05月25日 22:44:00
 */
public interface ArticleService {

    Page<Article> findAll(PageEntity page);
}
