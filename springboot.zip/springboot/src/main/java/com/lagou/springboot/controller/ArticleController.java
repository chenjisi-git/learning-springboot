package com.lagou.springboot.controller;

import com.lagou.springboot.entity.Article;
import com.lagou.springboot.service.ArticleService;
import com.lagou.springboot.util.PageEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author cjs
 * @version 1.0.0
 * @className ArticleController
 * @description TODO
 * @createTime 2020年05月25日 22:46:00
 */
@Controller
public class ArticleController {

    @Autowired
    private ArticleService articleService;

    /**
     * @author cjs
     * @description //获取文章列表
     * @date 2020/5/25 22:48 
     * @param
     * @return java.lang.Object
     **/
    @GetMapping("/index")
    public Object findArticles(PageEntity page, Model model)  {
        Page<Article> articlePage = articleService.findAll(page);
        model.addAttribute("list",articlePage.getContent() );
        model.addAttribute("pageNo",articlePage.getNumber());
        model.addAttribute("pageTotal",articlePage.getTotalPages());
        return "/client/index";
    }
}
