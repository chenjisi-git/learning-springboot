package com.lagou.springboot.service.impl;

import com.lagou.springboot.dao.ArticleRepository;
import com.lagou.springboot.entity.Article;
import com.lagou.springboot.service.ArticleService;
import com.lagou.springboot.util.PageEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ArticleServiceImpl implements ArticleService {

    @Autowired
    private ArticleRepository articleRepository;


    @Override
    public Page<Article> findAll(PageEntity pageEntity) {
        Pageable pageable = PageRequest.of(pageEntity.getPageNo(), pageEntity.getPageSize());
        return articleRepository.findAll(pageable);
    }
}
