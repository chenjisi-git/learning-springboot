package com.lagou.springboot.util;

/**
 * @author cjs
 * @version 1.0.0
 * @className PageEntity
 * @description TODO
 * @createTime 2020年05月25日 23:43:00
 */
public class PageEntity {

    private int pageNo=0;
    private int pageSize=3;

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        if(pageNo>0){
            this.pageNo = pageNo;
        }
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    @Override
    public String toString() {
        return "PageEntity{" +
                "pageNo=" + pageNo +
                ", pageSize=" + pageSize +
                '}';
    }
}
